# RPserver-web
Simple RP Server web template

Preview:
![](https://media.discordapp.net/attachments/960524367643705395/1010057777470783499/Screenshot_2022-08-19_111359.png?width=1279&height=676)
![]((https://media.discordapp.net/attachments/960524367643705395/1010057776862609448/Screenshot_2022-08-19_111418.png?width=1354&height=676)
![](https://media.discordapp.net/attachments/960524367643705395/1010057776304758834/Screenshot_2022-08-19_111435.png?width=1343&height=676)
![](https://media.discordapp.net/attachments/960524367643705395/1010057775914696704/Screenshot_2022-08-19_111509.png?width=1337&height=676)
![](https://media.discordapp.net/attachments/960524367643705395/1010057774849339432/Screenshot_2022-08-19_111549.png?width=1348&height=676)
